module protocol-characterizer

go 1.27.1

require github.com/google/gopacket v1.1.19

require golang.org/x/sys v0.0.0-20190412213103-97732733099d // indirect
